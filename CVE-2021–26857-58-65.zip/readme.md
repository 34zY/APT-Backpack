# ExProlog

ProxyLogon Full Exploit Chain PoC (CVE-2021–26855, CVE-2021–26857, CVE-2021–26858, CVE-2021–27065)

![demo](demo/demo.png)

```bash
Usage: exprolog.py [OPTIONS]

  ExProlog - ProxyLogon Full Exploit Chain PoC

  (CVE-2021–26855, CVE-2021–26857, CVE-2021–26858, CVE-2021–27065)

Options:
  -t, --target TEXT       MS Exchange Server (e.g. outlook.victim.corp).
  -e, --email TEXT        Email (e.g. administrator@victim.corp).
  -x, --execute TEXT      Execute verification shell.
  -i, --interactive TEXT  Run interactive shell.
  --help                  Show this message and exit.
```

## License

This project is licensed under the GNU GPLv3 License - see the [LICENSE](LICENSE) file for details

## Disclaimer

THIS TOOL IS BEING PROVIDED FOR EDUCATIONAL PURPOSES ONLY, WITH THE INTENT FOR RESEARCH PURPOSES ONLY.

You may not use this software for any illegal or unethical purpose; including activities which would give rise to criminal or civil liability.

USE ON YOUR OWN RISK. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER OR CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES.
