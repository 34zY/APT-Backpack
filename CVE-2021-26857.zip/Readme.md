# Proxylogon-exploit
proxylogon exploit - CVE-2021-26857

## usage:
```
python exploit.py <ip> <email_address>
```